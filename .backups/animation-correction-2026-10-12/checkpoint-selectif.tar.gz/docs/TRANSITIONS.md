# Chronologie des transitions

Le lanceur du dossier historique délègue à `/home/ali/Desktop/zawedni-story-3d/present.sh`.
Les corrections sont dans ce projet indépendant. Les exports du contenu et les notes
acceptées ne sont pas modifiés.

`src/nav/timeline.ts` décrit une chronologie absolue, échantillonnée par le directeur :

- sortie du contenu : 240 ms, caméra et poses maintenues ;
- déplacement : distance du trajet caméra / 14 unités par seconde, entre 650 ms
  et 6,5 s, avec un minimum supplémentaire pour la marche visible ;
- stabilisation : 180 ms, contenu toujours entièrement caché ;
- entrée du contenu : 300 ms, caméra arrivée, marche terminée.

Une révélation sans déplacement dure 300 ms (120 ms de sortie, 180 ms d'entrée).
Le mode léger conserve exactement la même chronologie. Le mouvement réduit
conserve la sortie puis l'entrée, avec le changement de pose pendant l'occultation.
Cette préférence est figée au départ de chaque transition.

Le directeur masque la couche de contenu entière pendant le mouvement, y compris
le panneau générique `evidence`, les anciens titres, la couverture et le film.
Les animations CSS indépendantes des panneaux sont désactivées. Le film est mis
en pause lors d'une navigation et ne démarre qu'à son apparition à destination.
Les repères intégrés au décor 3D restent disponibles.

La caméra utilise de courtes accélérations/décélérations autour d'une vitesse
centrale constante. La longueur mesurée inclut les éventuelles courbes surélevées.
Comme auparavant, les grands changements de lieu masquent le personnage pendant
la relocalisation, puis montrent au maximum les 2,6 derniers mètres à pied. La durée
réserve suffisamment de temps pour limiter cette marche à 1,8 m/s. Le cycle est
évalué depuis la distance réelle et son poids est nul dès l'arrêt.

Une commande pendant un déplacement capture la caméra, les poses et l'opacité
effectivement affichées. Elle remplace la chronologie courante sans terminer ni
révéler l'ancienne destination. Les clics rapides utilisent toujours l'index logique
de navigation ; les panneaux utilisent l'état effectivement affiché.
Les frames perdues sont rattrapées par l'horloge, sans accumulation de délais.

Vérification reproductible :

```sh
npm test
npm run build
ZS3D_NO_BROWSER=1 ./present.sh
node scripts/verify-transitions.mjs
node scripts/verify-transition-recovery.mjs
node scripts/render-transition-recording.mjs
npm run verify:classic
```

`verify-transitions.mjs` ouvre automatiquement les vraies notes, utilise les touches
de celles-ci, vérifie chaque changement de cadrage dans les deux sens en modes
normal et léger, les six sauts de chapitre et les clics rapides. Les courtes phases
d'interruption sont aussi échantillonnées explicitement pour les pilotes logiciels
qui perdent des frames. Les autres trajets et les enregistrements sont en temps réel.
Le rapport distingue les phases effectivement observées. Il vérifie l'occultation
sur chaque frame, l'arrêt de la marche et le contenu final, ainsi que l'absence
d'exceptions et de requêtes externes. Aucun accès réseau externe ni capacité nouvelle
n'est introduit par l'implémentation ; les validations des commandes et du HTML local
restent actives.

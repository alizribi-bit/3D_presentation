import { minimumArrivalDuration } from '../characters/arrival.ts';

export interface TransitionTiming {
  readonly exit: number;
  readonly movement: number;
  readonly settle: number;
  readonly enter: number;
  readonly arrival: number;
  readonly total: number;
}
export interface TransitionFrame {
  readonly phase: 'exit' | 'move' | 'settle' | 'enter' | 'done';
  readonly opacity: number;
  readonly progress: number;
  readonly movementTime: number;
  readonly complete: boolean;
}
const clamp = (n: number, min = 0, max = 1): number => Math.min(max, Math.max(min, n));
const smooth = (n: number): number => { const k = clamp(n); return k * k * (3 - 2 * k); };

/** Distance is measured along the camera curve, including its lift and change of framing.
 * Visible walking covers the final 2.6 m; the long relocation happens while faded out.
 * Its 38% movement window needs enough time to stay below 1.8 m/s, even on reverse/jump. */
export function transitionTiming(distance: number, walkingLength: number, reduced = false, fast = false): TransitionTiming {
  const moves = distance > 1e-5 || walkingLength > 1e-5;
  const walkMinimum = minimumArrivalDuration(walkingLength);
  const movement = fast ? (moves ? .03 : 0) : reduced ? 0
    : moves ? clamp(Math.max(distance / 14, walkMinimum), .65, 6.5) : 0;
  const exit = fast ? .01 : moves && !reduced ? .24 : .12;
  const settle = movement ? .18 : 0;
  const enter = fast ? .01 : moves && !reduced ? .3 : .18;
  const arrival = exit + movement + settle;
  return { exit, movement, settle, enter, arrival, total: arrival + enter };
}

/** One absolute timestamp drives content opacity, camera progress and the walk distance.
 * A dropped frame catches up directly; it never accumulates delays or leaves a hidden panel. */
export function transitionFrame(timing: TransitionTiming, elapsed: number, initialOpacity = 1): TransitionFrame {
  const t = Math.max(0, elapsed);
  const movementTime = clamp(t - timing.exit, 0, timing.movement);
  const progress = timing.movement ? movementTime / timing.movement : t < timing.exit ? 0 : 1;
  const phase = t < timing.exit ? 'exit' : t < timing.exit + timing.movement ? 'move'
    : t < timing.arrival ? 'settle' : t < timing.total ? 'enter' : 'done';
  const opacity = phase === 'exit' ? initialOpacity * (1 - smooth(t / timing.exit))
    : phase === 'enter' ? smooth((t - timing.arrival) / timing.enter) : phase === 'done' ? 1 : 0;
  return { phase, opacity, progress, movementTime, complete: t >= timing.total };
}

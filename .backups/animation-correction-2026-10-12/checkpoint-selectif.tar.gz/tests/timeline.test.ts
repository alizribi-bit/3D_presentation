import test from 'node:test';
import assert from 'node:assert/strict';
import { transitionFrame, transitionTiming } from '../src/nav/timeline.ts';
import { arrivalWalk } from '../src/characters/arrival.ts';
import { ease, shotDistance } from '../src/camera/rig.js';

test('content is fully gone before movement and stays hidden until stabilization ends', () => {
  const timing = transitionTiming(45, 40);
  assert.equal(transitionFrame(timing, 0).opacity, 1);
  for (let t = timing.exit; t < timing.arrival; t += .013) {
    const frame = transitionFrame(timing, t);
    assert.equal(frame.opacity, 0);
    if (frame.phase === 'settle') assert.equal(frame.progress, 1);
  }
  assert.equal(transitionFrame(timing, timing.exit).progress, 0);
  assert.equal(transitionFrame(timing, timing.arrival).opacity, 0);
  assert.ok(transitionFrame(timing, timing.arrival + .15).opacity > 0);
  assert.equal(transitionFrame(timing, timing.total).complete, true);
});

test('camera travel is distance based, bounded, and the visible stride keeps a human pace', () => {
  const near = transitionTiming(14, 0), far = transitionTiming(28, 0);
  assert.equal(far.movement / near.movement, 2);
  assert.equal(transitionTiming(10000, 0).movement, 6.5);
  assert.equal(transitionTiming(.01, 0).movement, .65);
  for (const distance of [1, 14, 50, 130]) {
    const timing = transitionTiming(distance, 40);
    let previous = 0;
    for (let t = 0; t < timing.total; t += .005) {
      const frame = transitionFrame(timing, t);
      const walk = arrivalWalk(frame.movementTime, timing.movement, 40);
      assert.ok((walk.distance - previous) / .005 <= 1.801);
      if (frame.phase === 'enter' || frame.phase === 'settle') assert.equal(walk.walking, false);
      previous = walk.distance;
    }
  }
});

test('interruptions start at the actual opacity and dropped frames reach the final content', () => {
  const timing = transitionTiming(45, 40);
  for (const opacity of [0, .3, 1]) {
    assert.equal(transitionFrame(timing, 0, opacity).opacity, opacity);
    assert.equal(transitionFrame(timing, timing.exit, opacity).opacity, 0);
    const complete = transitionFrame(timing, 100, opacity);
    assert.equal(complete.opacity, 1);
    assert.equal(complete.progress, 1);
    assert.equal(complete.complete, true);
  }
});

test('text-only reveals stay short and reduced motion retains exit before arrival', () => {
  const text = transitionTiming(0, 0);
  assert.equal(text.movement, 0);
  assert.equal(text.total, .3);
  const reduced = transitionTiming(90, 40, true);
  assert.equal(transitionFrame(reduced, 0).progress, 0);
  assert.equal(transitionFrame(reduced, reduced.exit).progress, 1);
  assert.equal(transitionFrame(reduced, reduced.exit).opacity, 0);
  assert.equal(transitionFrame(reduced, reduced.total).opacity, 1);
});

test('camera distance accounts for lifted paths and easing has a constant central pace', () => {
  const a = { pos: [0, 0, 0], target: [0, 0, -1], fov: 38 };
  const b = { pos: [28, 0, 0], target: [28, 0, -1], fov: 38 };
  assert.equal(shotDistance(a, b), 28);
  assert.ok(shotDistance(a, b, 16) > 28);
  assert.ok(Math.abs((ease(.4) - ease(.3)) - (ease(.7) - ease(.6))) < 1e-9);
});

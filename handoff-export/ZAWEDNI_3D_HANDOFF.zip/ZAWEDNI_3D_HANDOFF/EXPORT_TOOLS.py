"""Verify the handoff, then materialize the existing build without compilation.

Only an extracted handoff (with EXPORT_STATE.json) can be restored. Validate all
inputs before copying; never overwrite a different existing build asset.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path, PurePosixPath


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe_path(root: Path, name: str) -> Path:
    relative = PurePosixPath(name)
    if relative.is_absolute() or '..' in relative.parts or '\\' in name:
        raise ValueError(f'Unsafe path: {name}')
    target = root.joinpath(*relative.parts)
    for part in [target, *target.parents]:
        if part == root:
            break
        if part.is_symlink():
            raise ValueError(f'Symlink refused: {name}')
    if not target.resolve().is_relative_to(root.resolve()):
        raise ValueError(f'Path outside export: {name}')
    return target


def require_hash(root: Path, name: str, expected: str) -> Path:
    file = safe_path(root, name)
    if not file.is_file() or digest(file) != expected:
        raise ValueError(f'Missing or changed file: {name}')
    return file


def verify(root: Path) -> int:
    manifest = json.loads((root / 'MANIFEST_SHA256.json').read_text())
    for name, expected in manifest['files'].items():
        require_hash(root, name, expected)
    return len(manifest['files'])


def restore(root: Path) -> int:
    if not (root / 'EXPORT_STATE.json').is_file():
        raise ValueError('Restore is restricted to an extracted handoff.')
    mapping = json.loads((root / 'RUNTIME_RESTORE.json').read_text())['files']
    identity = json.loads((root / 'dist/build-info.json').read_text())
    for name, expected in identity['sourceFiles'].items():
        require_hash(root, name, expected)
    missing: list[tuple[Path, Path]] = []
    for name, expected in identity['files'].items():
        destination = safe_path(root, 'dist/' + name)
        if destination.exists():
            require_hash(root, 'dist/' + name, expected)
        else:
            record = mapping.get(name)
            if record is None or record['sha256'] != expected or record['source'] != 'public/' + name:
                raise ValueError(f'No original runtime asset for: {name}')
            source = require_hash(root, record['source'], expected)
            missing.append((source, destination))
    # Validation is complete. These are copies of accepted public files, not a build.
    for source, destination in missing:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
    for name, expected in identity['files'].items():
        require_hash(root, 'dist/' + name, expected)
    return len(missing)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['verify', 'restore'])
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    count = verify(root)
    print(f'SHA-256 verified: {count} files')
    if args.command == 'restore':
        print(f'Existing build restored: {restore(root)} assets copied; no compilation')


if __name__ == '__main__':
    main()

Baseline src/ extrait sans checkout/reset du commit b43378c (b43378cebe8fd7ae2ff1eb9da69078564087945c).
Les sources actuelles restent à la racine src/. Ce dossier est une référence, pas un build.

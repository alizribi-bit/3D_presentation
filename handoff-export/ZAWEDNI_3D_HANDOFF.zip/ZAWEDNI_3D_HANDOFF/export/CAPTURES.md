# Captures existantes sélectionnées

Aucune nouvelle capture exécutée pour cet export. Les images de correction sont plus récentes que les paires de référence classique.

- [jury-light-1366.png](../review/animation-correction-2026-10-12/jury-light-1366.png) — 272994 octets ; mtime 2026-10-12T19:09:20.492554+00:00
- [jury-light-1920.png](../review/animation-correction-2026-10-12/jury-light-1920.png) — 442862 octets ; mtime 2026-10-12T19:06:09.425590+00:00
- [jury-normal-1366.png](../review/animation-correction-2026-10-12/jury-normal-1366.png) — 294752 octets ; mtime 2026-10-12T19:17:16.518806+00:00
- [jury-normal-1920.png](../review/animation-correction-2026-10-12/jury-normal-1920.png) — 475664 octets ; mtime 2026-10-12T19:14:29.537145+00:00
- [notes-light-1366.png](../review/animation-correction-2026-10-12/notes-light-1366.png) — 79312 octets ; mtime 2026-10-12T19:09:23.256552+00:00
- [notes-light-1920.png](../review/animation-correction-2026-10-12/notes-light-1920.png) — 79013 octets ; mtime 2026-10-12T19:06:13.540591+00:00
- [notes-normal-1366.png](../review/animation-correction-2026-10-12/notes-normal-1366.png) — 79406 octets ; mtime 2026-10-12T19:17:19.443799+00:00
- [notes-normal-1920.png](../review/animation-correction-2026-10-12/notes-normal-1920.png) — 79513 octets ; mtime 2026-10-12T19:14:34.483135+00:00
- [architecture-3-jury.png](../review/classic/1920x1080/architecture-3-jury.png) — 463269 octets ; mtime 2026-10-12T15:38:58.923759+00:00
- [architecture-3-presenter.png](../review/classic/1920x1080/architecture-3-presenter.png) — 105191 octets ; mtime 2026-10-12T15:39:01.538564+00:00
- [bilan-2-jury.png](../review/classic/1920x1080/bilan-2-jury.png) — 364350 octets ; mtime 2026-10-12T16:49:34.310126+00:00
- [bilan-2-presenter.png](../review/classic/1920x1080/bilan-2-presenter.png) — 99679 octets ; mtime 2026-10-12T16:49:37.967117+00:00

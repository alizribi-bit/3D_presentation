"""Meaningful negative checks for restoration; writes only disposable export fixtures."""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from EXPORT_TOOLS import restore, safe_path


class ExportRestoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory(prefix='zawedni-export-fixture-')
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        (self.root / 'public').mkdir()
        (self.root / 'dist').mkdir()
        (self.root / 'EXPORT_STATE.json').write_text('{}')
        self.asset = self.root / 'public/model.glb'
        self.asset.write_bytes(b'accepted runtime model')
        sha = hashlib.sha256(self.asset.read_bytes()).hexdigest()
        (self.root / 'RUNTIME_RESTORE.json').write_text(json.dumps({'files': {
            'model.glb': {'source': 'public/model.glb', 'sha256': sha},
        }}))
        (self.root / 'dist/build-info.json').write_text(json.dumps({
            'files': {'model.glb': sha}, 'sourceFiles': {'public/model.glb': sha},
        }))

    def test_exact_copy_and_idempotence(self) -> None:
        self.assertEqual(restore(self.root), 1)
        self.assertEqual((self.root / 'dist/model.glb').read_bytes(), self.asset.read_bytes())
        self.assertEqual(restore(self.root), 0)

    def test_corrupt_source_rejected_before_writes(self) -> None:
        self.asset.write_bytes(b'changed')
        with self.assertRaises(ValueError):
            restore(self.root)
        self.assertFalse((self.root / 'dist/model.glb').exists())

    def test_existing_different_asset_is_never_overwritten(self) -> None:
        target = self.root / 'dist/model.glb'
        target.write_bytes(b'other build')
        with self.assertRaises(ValueError):
            restore(self.root)
        self.assertEqual(target.read_bytes(), b'other build')

    def test_traversal_and_symlink_rejected(self) -> None:
        with self.assertRaises(ValueError):
            safe_path(self.root, '../outside')
        (self.root / 'escape').symlink_to(self.root / 'public', target_is_directory=True)
        with self.assertRaises(ValueError):
            safe_path(self.root, 'escape/model.glb')

    def test_export_marker_required(self) -> None:
        (self.root / 'EXPORT_STATE.json').unlink()
        with self.assertRaises(ValueError):
            restore(self.root)


if __name__ == '__main__':
    unittest.main()
